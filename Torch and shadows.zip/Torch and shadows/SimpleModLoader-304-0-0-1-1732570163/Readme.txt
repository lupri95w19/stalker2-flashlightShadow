=================================
 INFO
=================================
Mod enabled dev console as well as acts as a siple BP modloader
Supports CME only mods as well.


=================================
 INSTALL
=================================
0. !! DELETE FILES "pakchunk222.*" AND "pakchunk99.*" IF YOU HAVD OLD VERSION INSTALLED !!
1. STEAM: Go to your Steam Library, find "STALKER 2", right-click, Manage -> Browse Local Files.
          This is your game root folder.
2. Extract content of the zip-archive inside root folder. If you did everything correctly,
   "Simple_ModLoader.*"
   will be present inside "Stalker2\Content\Paks\".
3. Installation complete.


=================================
 UNINSTALL
=================================
Delete aforementioned files


=================================
 CONFLICTS
=================================
The mod already enables console so you dont need to install any console mods.
Other *OLD* BP mods might conflict.


=================================
 USAGE
=================================

[~] or [`] to call console. See below how to change the key

Terms:
- scp :: soft-class path

Commands:

mod add <scp> :: adds BP mod to auto load list and instantly spawn it if needed
mod del <scp> :: removes mod from list and destroys instance
mod print *   :: prints list currently saved mods
-
cme add <scp> :: adds CME to auto load list and instantly spawns if needed
cme del <scp> :: removes cme from extensions collection
mod print *   :: prints list currently saved cmes
-
clearall      :: removes all entries from aut-load DB
-
conset smallfontsize <size> :: sets console font size
-

Once a mod or cme is added, it will be auto-reloaded on save reload.
P.S. Other S2HOC specific console commands included


=================================
 FAQ
=================================
- How to change console key? -

a) Open in Notepad 
﻿%LOCALAPPDATA%\Stalker2\Saved\Config\Windows\Input.ini
b) Add to the very top section:
[/Script/Engine.InputSettings]
ConsoleKeys=Tilde
ConsoleKeys=RightBracket
c) Replace "RightBracket" with a key of your choice:
https://nerivec.github.io/old-ue4-wiki/pages/list-of-keygamepad-input-names.html


- How to add a mod? -

For end-users: simply read the mod's readme and find out what path mod uses as per
developer's description and then use command:
"mod add path" or "cme add path"

For developers: copy reference to your asset via UE menu, take the path inside ''
quotes and append "_C" to the of it to make soft class path, for example:
   /Script/Engine.Blueprint'/Game/Mods/FLCustomizer/BP_MOD_FLCustomizer.BP_MOD_FLCustomizer'
turns into
   /Game/Mods/FLCustomizer/BP_MOD_FLCustomizer.BP_MOD_FLCustomizer_C

Asset name does not matter. Location does not matter.


=================================
 KNOWN ISSUES
=================================
- ???


=================================
 HOW TO REPORT ISSUES
=================================
- descibe exact steps/what you did that lead to the bug
- provide savegames before and after if possible (%LOCALAPPDATA%\Stalker2\Saved\)


=================================
 CHANGELOG
=================================
- v0.0.1 - Initial release


=================================
 CREDITS
=================================
KeinZantezuken