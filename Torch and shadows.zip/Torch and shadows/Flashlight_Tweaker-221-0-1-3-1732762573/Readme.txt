=================================
 INFO
=================================
Mod adds console commands to tweak head light.


=================================
 SCP
=================================
/Game/Mods/FLCustomizer/BP_MOD_FLCustomizer.BP_MOD_FLCustomizer_C


=================================
 INSTALL
=================================
0. !! DELETE FILES "pakchunk221.*" AND "pakchunk222.*" IF YOU HAVD OLD VERSION INSTALLED !!
1. Install: https://www.nexusmods.com/stalker2heartofchornobyl/mods/304/
2. STEAM: Go to your Steam Library, find "STALKER 2", right-click, Manage -> Browse Local Files.
          This is your game root folder.
3. Extract content of the zip-archive inside root folder. If you did everything correctly,
   "Flashlight_Customizer.*"
   will be present inside "Stalker2\Content\Paks\".
4. In-game, execute command:
   mod add /Game/Mods/FLCustomizer/BP_MOD_FLCustomizer.BP_MOD_FLCustomizer_C

=================================
 UNINSTALL
=================================
Either:
 mod del /Game/Mods/FLCustomizer/BP_MOD_FLCustomizer.BP_MOD_FLCustomizer_C
Or
 delete aforementioned files


=================================
 CONFLICTS
=================================
None

=================================
 USAGE
=================================

Simply configure the flashlight preset to your liking with commands below
and the execute "fl_state save" - the preset will be automatically loaded
upon restart.

To delete the preset, go to "%LOCALAPPDATA%\Stalker2\Saved\SaveGames\"
and delete the file "fldata.sav"

To share preset, simply share "fldata.sav"

fl_intensity x.x             :: adjust intensity
fl_radius x.x                :: adjust radius
fl_attenuation x.x           :: adjust attenuation radius
fl_sourcelen   x.x           :: adjust source length
fl_specular x.x              :: adjust specular scale
fl_color (R=x.x,G=x.x,B=x.x) :: adjust color, normalized used (0.0 to 1.0)
fl_cone inner|outer x.x      :: adjusts cone values
-
fl_shadows normal true|false  :: enables shadow casting
fl_shadows deep true|false    :: enables deep shadows
fl_shadows volume true|false  :: enables volumetric shadows
fl_shadows dynamic true|false :: enables dynamic shadows
fl_shadows fg true|false      :: enables foreground shadows
fl_shadows rt true|false      :: enforces raytracing shadows
-
fl_transform (X=x.x,Y=x.x,Z=x.x) :: manipulates offset
-
fl_state print               :: pints current setup or defaults
fl_state save                :: saves preset
fl_state load                :: loads preset

Your shadow quality in options needs to be High at least for shadows to work.

=================================
 KNOWN ISSUES
=================================
- GamePass version is not supported! It might work but preset saving wont.
- sometimes preset autoload fails due to race condition - in this case load manually


=================================
 HOW TO REPORT ISSUES
=================================
- describe exact steps/what you did that lead to the bug
- provide savegames before and after if possible (%LOCALAPPDATA%\Stalker2\Saved\)


=================================
 CHANGELOG
=================================
- v0.1.3 - fixed bugs with some settigns not loading properly (dyn shadows)
         - added inner/outer cone saving
         - added Ray Tracing shadows enforce
- v0.1.2 - added ability to tweak inner|outer cone
- v0.1.1 - added ability to tweak offset/location
- v0.1.0 - BREAKING CHANGE: rewrote for modloader
- v0.0.4 - small readme update
- v0.0.3 - added autoload, renamed the mod paks
- v0.0.2 - added shadows
- v0.0.1 - Initial release


=================================
 CREDITS
=================================
KeinZantezuken