I'm not the creator of these two mods, I just wanted to let you know how you can activate shadows casted by flashlight.
MODS PAGES
https://www.nexusmods.com/stalker2heartofchornobyl/mods/304?tab=docs
https://www.nexusmods.com/stalker2heartofchornobyl/mods/221?tab=docs

You need to drop both mods in Paks folder, for example:
C:\Program Files (x86)\Steam\steamapps\common\S.T.A.L.K.E.R. 2 Heart of Chornobyl\Stalker2\Content\Paks

In case of any crash delete these files "pakchunk99.*", "pakchunk221.*" AND "pakchunk222.*".



Now to activate these shadows you need to launch the game, in game you need to open the dev console by using "~" or "`".
Or you can configure it, go to "C:\Users\yourUser\AppData\Local\Stalker2\Saved\Config\Windows" and open Input.ini and under [/script/engine.inputsettings] (if it's not present add it)

[/script/engine.inputsettings]
ConsoleKeys=Tilde
ConsoleKeys=RightBracket
ConsoleKeys=Backslash
; ConsoleKeys=addYourKey ; this is a commented line

you can find all chars here https://nerivec.github.io/old-ue4-wiki/pages/list-of-keygamepad-input-names.html



Now in game you need to type this (without ""):
"mod add /Game/Mods/FLCustomizer/BP_MOD_FLCustomizer.BP_MOD_FLCustomizer_C"

Now you can type this fl_shadows normal true | fl_shadows volume true
Congratulations now your game looks more like a 2024 game.

To make this any easier I'm gonna upload my Input.ini so you have my history of commands.